
exports.getListSP = (req,res,next)=>{
    // hàm hiện danh sách 
    let tieuDe = "Danh sách sản phẩm mới ";
    console.log(req.body);
    let uname = '';
    if(typeof(req.body.username)!= 'undefined')
        uname = req.body.username;
    

    res.render('sanpham/list' , { title: tieuDe , uname:uname });
}

exports.getFormAdd = (req,res,next)=>{
    // hàm hiện form thêm
    res.render('sanpham/add');
}