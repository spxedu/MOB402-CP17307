var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/gioithieu.html', (req,res,next)=>{
    // res.send("<h1>Giới thiệu</h1>");
    res.render('gioithieu',{ hoten:"Nguyen Van A"});
} );

// router.get('/sanpham', (req, res, next)=>{
//   // localhost:3000/sanpham?id=5
//     // lấy dữ liệu theo query sẽ dùng thuộc tính query
//     console.log("Lấy dữ liệu theo query  ");
//     console.log(req.url);
//     console.log(req.query); // các tham số nằm trong đối tượng query.
//     res.send("Trang sản phẩm: id = " +  req.query.id );
// })

// router.get('/sanpham/:id?', (req,res)=>{
//   // trường hợp cho phép truy cập địa chỉ mà không cần có tham số id thì viết thêm dấu ? ở sau id
//     console.log("Truyền dữ liệu theo Params ");
//     console.log(req.url);
//     console.log(req.params); // các tham số nằm trong đối tượng query.
//     res.send("Trang sản phẩm: id = " +  req.params.id );
// })

router.post('/sanpham',(req,res,next)=>{
    console.log("Dữ liệu post");
    console.log(req.body);
    res.send(req.body);
})

module.exports = router;
