var express = require('express');
var router = express.Router();
var spController = require('../controllers/sanpham.controller');
// tạo các trang ở đây

router.get('/list', spController.getListSP );
router.get('/add', spController.getFormAdd );

router.post('/list', spController.getListSP );


module.exports = router;
